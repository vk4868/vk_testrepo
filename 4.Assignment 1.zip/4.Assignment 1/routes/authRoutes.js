const express = require('express');
const { MongoClient } = require('mongodb');
const passport = require('passport');
const authRouter = express.Router();
const User = require('../db/user')

authRouter.post('/signUp', async (req, res) => {

    const body = req.body;
    username = body.username;
    password = body.password;
    let result = await User.findOne({ username: username })
    if (
        result
    ) {
        return res.status(409).send('Username already exists')

    }
    const record = new User()
    record.username = username;
    record.password = record.hashPassword(password)

    await record.save()
    res.json(record)

})

authRouter.post('/signin',passport.authenticate('local',
{
    successRedirect:'/details',
    failureRedirect:'/auth/signUp'
}),(req,res) =>{
    res.send('Hello welcome')
}
)

authRouter.get('/signin',(req,res,nav)=>{
    res.render('signin',{
       nav,
       title:'Sign in'

    });

 });

 module.exports = authRouter
// (err, doc) => {
//     if (err) { res.status(500).send('error occured') }
//     else {
//         if (doc) {
//             res.status(500).send('Username already exists')
//         }
//         else {
//             const record = new User()
//             record.username = username;
//             record.password = record.hashPassword(password)
//             record.save(function (err, user) {
//                 if (err) {
//                     res.status(500).send('db error')
//                 } else {
//                     res.send(user)
//                 }

//                 res.json('hello')






// module.exports = function(passport){
//     authRouter.post('/signUp',(req,res)=>{
//         const body =req.body;
//         username =body.username;
//         password =body.password;
//         console.log(username,password)
//         User.findOne({username :username},(err,doc)=>{
//             if(err) {res.status(500).send('error occured')}
//             else {
//                 if(doc) {
//                     res.status(500).send('Username already exists')
//                 }
//                 else{
//                     const record =new User()
//                     record.username =username;
//                     record.password =record.hashPassword(password)
//                     record.save(function(err,user){
//                         if (err) {
//                             res.status(500).send('db error')
//                         } else{
//                             res.send(user)
//                         }


//                     }
//                     )}
//             }
//         })

//     })

// };


// // authRouter.post('/signUp',(req,res) =>{
// //     const {username,password} =req.body;
// //     const url ='mongodb://127.0.0.1:27017';
// //     const dbName ='Students';
// //     (async function addUser(){
// //         let client;
// //         try{
// //             client =await MongoClient.connect(url);
// //             debug('connected correctly to server')
// //             const db =client.db(dbName);
// //             const col =db.collection('users');
// //             const user ={username,password};
// //             const result =await col.insertOne(user);
// //             debug(results);
// //         } catch(err){
// //             debug(err);

// //         }

// //     }())
// //     debug(req.body);
// //     req.login(req.body, () =>{
// //         res.redirect('/auth/profile');
// //     })

// // });

 
// // authRouter.post('/signin',passport.authenticate('local', {
// //     successRedirect:'/details',
// //     failureRedirect:'/',


// // }))

// // authRouter.get('/profile',(req,res) =>{
// //     res.json(req.user);
// //     return authRouter    
// // })
