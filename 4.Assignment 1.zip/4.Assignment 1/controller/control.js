const model =require('../db/model')

let studentInfo ={
    submitStudent: async(req,res)=>{
        console.log('Student submitted');
        const student= new model({
            name: req.body.name,
            class:req.body.class
        });

        try{
            const savedStudent = await student.save();
            res.json(savedStudent);
        }catch(err){
            res.json({message:err});
        }
    }
}
module.exports = studentInfo