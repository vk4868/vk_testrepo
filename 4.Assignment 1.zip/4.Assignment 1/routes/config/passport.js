const localStrategy = require('passport-local').Strategy;
const User =require('../../db/user')

module.exports =function(passport){
    passport.serializeUser(function(user,done){
        done(null,user)

    })
    passport.deserializeUser(function(user,done){
        done(null,user)

    })
    passport.use(new localStrategy(function(username,password,done){
        User.findOne({username:username},(err,doc)=>{
            if(err){done(err)}
            else{
                if(doc){
                    let valid =doc.comparePassword(password,doc.password)
                    if(valid) {
                        done(null,{
                            username:doc.username,
                            password:doc.password
                        })
                    }
                    else{
                        done(null,false)
                    }
                }else{
                    done(null,false)
                }

            }

        })

    }))
        }

// const passport =require('passport');
// const localStrategy =require('passport-local').Strategy
// require('./strategy/local.strategy')();



//  function passportConfig(app){
//     app.use(passport.initialize()); //passport sets itself up on the app
//      app.use(passport.session()); //build up the session and pull things out
     

     

//     //Stores user in session
//     passport.serializeUser((user,done) =>{
//         done(null,user)

//     });

//     //Retrieves user 
//     passport.deserializeUser((user,done) =>{
//         done(null,user)
//     });
   

// }
// module.exports =passportConfig