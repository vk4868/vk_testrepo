const express =require('express');
const path =require('path')
const app =express()
require('./db/model')
require('./db/user')
require('./db/connection')
const bodyParser =require('body-parser')
const routes = require('./routes/route');
const passport =require('passport');
const LocalStrategy =require('passport-local');
const authRouter = require('./routes/authRoutes');
const cookieParser =require('cookie-parser');
const session =require('express-session');
const { Passport } = require('passport');
require('./routes/config/passport')


app.use(express.json())
app.use(bodyParser.urlencoded({extended:false})); //??
app.use(cookieParser());
app.use(session({secret: 'student'})) //it is just something that uses when it builds the cookie
app.use(passport.initialize());
app.use(passport.session())


// require('./routes/config/passport')(passport);



app.set('index','./views/index')
app.set('firstpage','./views/firstpage')
app.set('signin','./views/signin')
app.set('view engine', 'ejs');
    

app.use('/', routes)
app.use('/auth',authRouter);
app.listen(4000,()=>{
    console.log('Server is running')
})

