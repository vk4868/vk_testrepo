const express =require('express');
const { Mongoose } = require('mongoose');

const studentInfo = require('../controller/control')
const models =require('../db/model')
const router =express.Router();

router.get('/auth/signUp',(req,res) =>{
    res.render('firstpage')
})
router.get('/details', (req,res) => {
    models.find({},function(err,students){
        res.render('index',{
            studentList: students
            
        })

    })
})

router.post('/posts', studentInfo.submitStudent)

router.post('/register',(req,res) =>{
    res.send('register')
})

module.exports = router
